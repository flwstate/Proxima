
  # One-Page Website Design (Copy)

  This is a code bundle for One-Page Website Design (Copy). The original project is available at https://www.figma.com/design/YzSU3Q1GPDskqWClNQaJYr/One-Page-Website-Design--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  