import { FloatingNav } from './components/FloatingNav';
import { HeroSection } from './components/HeroSection';
import { ProblemSection } from './components/ProblemSection';
import { SolutionSection } from './components/SolutionSection';
import { UserJourneySection } from './components/UserJourneySection';
import { AIEngineSection } from './components/AIEngineSection';
import { UnderTheHoodSection } from './components/UnderTheHoodSection';
import { ReflectionsSection } from './components/ReflectionsSection';
import { ProximityChatSection } from './components/ProximityChatSection';
import { AIChatSection } from './components/AIChatSection';
import { EventsSection } from './components/EventsSection';
import { ZonesSection } from './components/ZonesSection';
import { SafetySection } from './components/SafetySection';
import { MarketFitSection } from './components/MarketFitSection';
import { MarketSizeSection } from './components/MarketSizeSection';
import { MonetizationSection } from './components/MonetizationSection';
import { GoToMarketSection } from './components/GoToMarketSection';
import { ProgressSection } from './components/ProgressSection';
import { TeamSection } from './components/TeamSection';
import { FounderSection } from './components/FounderSection';
import { TheAskSection } from './components/TheAskSection';
import { Footer } from './components/Footer';
import { Toaster } from './components/ui/sonner';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Floating Navigation */}
      <FloatingNav />

      {/* All Sections */}
      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <UserJourneySection />
      <AIEngineSection />
      <UnderTheHoodSection />
      <ReflectionsSection />
      <ProximityChatSection />
      <AIChatSection />
      <EventsSection />
      <ZonesSection />
      <SafetySection />
      <MarketFitSection />
      <MarketSizeSection />
      <MonetizationSection />
      <GoToMarketSection />
      <ProgressSection />
      <TeamSection />
      <FounderSection />
      <TheAskSection />
      <Footer />

      {/* Toast Notifications */}
      <Toaster />
    </div>
  );
}
