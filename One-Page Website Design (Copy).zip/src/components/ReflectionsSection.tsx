import { motion } from 'motion/react';
import { MapPin, MessageCircle, Camera, Heart, Lightbulb, AlertCircle, Calendar, Compass as CompassIcon } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const reflectionTypes = [
  { name: 'Thought', icon: Lightbulb, color: '#FF7A00' },
  { name: 'Memory', icon: Heart, color: '#FF8C1A' },
  { name: 'Tip', icon: CompassIcon, color: '#FF9E33' },
  { name: 'Alert', icon: AlertCircle, color: '#FFB04D' },
  { name: 'Story', icon: MessageCircle, color: '#FFC266' },
  { name: 'Moment', icon: Camera, color: '#FFD480' },
  { name: 'Event', icon: Calendar, color: '#FF7A00' },
  { name: 'Discovery', icon: MapPin, color: '#FF8C1A' },
];

const platformComparison = [
  { platform: 'Instagram', focus: 'Photo sharing', limitation: 'No location pinning' },
  { platform: 'TikTok', focus: 'Video content', limitation: 'Limited geo-context' },
  { platform: 'Yelp', focus: 'Business reviews', limitation: 'No personal stories' },
  { platform: 'Foursquare', focus: 'Check-ins', limitation: 'Outdated model' },
  { platform: 'Proxima', focus: 'Geo-pinned experiences', limitation: 'None – unified solution' },
];

export function ReflectionsSection() {
  return (
    <section className="relative py-24 bg-gradient-to-b from-[#0D0D0D] to-black overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Reflections Feature – Geo-Pinned Content</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Pin your thoughts, memories, and discoveries to real-world locations. Create a living map of experiences.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Map Illustration */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative aspect-square bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1713862032437-882c33dd611f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFwJTIwbG9jYXRpb258ZW58MXx8fHwxNzYxMDYxOTE2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Map"
                className="w-full h-full object-cover opacity-30"
              />
              
              {/* Floating Reflection Icons */}
              {reflectionTypes.map((type, index) => {
                const positions = [
                  { top: '15%', left: '20%' },
                  { top: '25%', left: '65%' },
                  { top: '40%', left: '35%' },
                  { top: '55%', left: '75%' },
                  { top: '65%', left: '15%' },
                  { top: '75%', left: '55%' },
                  { top: '30%', left: '85%' },
                  { top: '80%', left: '35%' },
                ];
                
                return (
                  <motion.div
                    key={index}
                    className="absolute"
                    style={positions[index]}
                    initial={{ scale: 0, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    whileHover={{ scale: 1.3, zIndex: 10 }}
                  >
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center border-2 cursor-pointer"
                      style={{
                        backgroundColor: `${type.color}20`,
                        borderColor: type.color,
                        boxShadow: `0 0 20px ${type.color}80`,
                      }}
                    >
                      <type.icon className="w-6 h-6" style={{ color: type.color }} />
                    </div>
                    
                    {/* Pulse Animation */}
                    <motion.div
                      className="absolute inset-0 rounded-full border-2"
                      style={{ borderColor: type.color }}
                      animate={{
                        scale: [1, 1.5, 1],
                        opacity: [0.5, 0, 0.5],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: index * 0.2,
                      }}
                    />
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* Reflection Types Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="mb-6 text-white">Types of Reflections</h3>
            <div className="grid grid-cols-2 gap-4">
              {reflectionTypes.map((type, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4 hover:border-[#FF7A00] transition-all group"
                  whileHover={{ scale: 1.05 }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform"
                    style={{
                      backgroundColor: `${type.color}20`,
                      border: `2px solid ${type.color}`,
                    }}
                  >
                    <type.icon className="w-5 h-5" style={{ color: type.color }} />
                  </div>
                  <h4 className="text-white">{type.name}</h4>
                </motion.div>
              ))}
            </div>

            <div className="mt-8 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-6 rounded-r-lg">
              <h4 className="text-white mb-3">How It Works</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li className="flex items-start gap-2">
                  <span className="text-[#FF7A00] mt-1">1.</span>
                  <span>Choose a location on the map or use your current position</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF7A00] mt-1">2.</span>
                  <span>Select a reflection type and create your content</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF7A00] mt-1">3.</span>
                  <span>Control visibility: public, friends-only, or private</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#FF7A00] mt-1">4.</span>
                  <span>Discover others' reflections as you explore the world</span>
                </li>
              </ul>
            </div>
          </motion.div>
        </div>

        {/* Platform Comparison Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-8 text-white">Platform Comparison</h3>
          <div className="grid md:grid-cols-5 gap-4">
            {platformComparison.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`p-6 rounded-lg border-2 ${
                  item.platform === 'Proxima'
                    ? 'bg-gradient-to-br from-[#FF7A00]/20 to-transparent border-[#FF7A00] shadow-[0_0_30px_rgba(255,122,0,0.3)]'
                    : 'bg-black/50 border-gray-700'
                }`}
              >
                <h4 className={`mb-3 ${item.platform === 'Proxima' ? 'text-[#FF7A00]' : 'text-gray-400'}`}>
                  {item.platform}
                </h4>
                <p className={`text-sm mb-2 ${item.platform === 'Proxima' ? 'text-white' : 'text-gray-500'}`}>
                  {item.focus}
                </p>
                <p className={`text-xs ${item.platform === 'Proxima' ? 'text-green-400' : 'text-red-400'}`}>
                  {item.limitation}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
