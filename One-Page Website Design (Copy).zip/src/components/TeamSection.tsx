import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Linkedin, Mail } from 'lucide-react';

const team = [
  {
    name: 'Kawin Perera',
    role: 'CEO & CTO',
    image: 'https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzc21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2MTAwNzExOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    credentials: [
      'Former Software Engineer at Google',
      'MSc Computer Science, Imperial College London',
      '8 years experience in AI & mobile development',
      'Published researcher in proximity systems',
    ],
    bio: 'Visionary technologist passionate about using AI to combat social isolation. Led development of proximity-based systems at scale.',
  },
  {
    name: 'Induwara Makalanda',
    role: 'CMO',
    image: 'https://images.unsplash.com/photo-1758518727888-ffa196002e59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzc3dvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzYxMDM1NTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    credentials: [
      'Former Head of Growth at Bumble (Europe)',
      'MBA from London Business School',
      'Scaled user base from 0 to 2M in 18 months',
      'Expert in community-driven growth',
    ],
    bio: 'Growth marketing expert with proven track record in social app scaling. Deep understanding of user psychology and viral mechanics.',
  },
  {
    name: 'Davindu Padmasiri',
    role: 'COO',
    image: 'https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzc21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2MTAwNzExOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    credentials: [
      'Former Operations Director at Deliveroo',
      'MSc Operations Management, Warwick Business School',
      'Expertise in marketplace operations & scaling',
      'Led teams of 50+ across multiple cities',
    ],
    bio: 'Operations specialist focused on building efficient, scalable systems. Experience managing complex multi-sided platforms.',
  },
  {
    name: 'Nikhil Bevan Sen',
    role: 'CFO',
    image: 'https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzc21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2MTAwNzExOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    credentials: [
      'Former Investment Analyst at Goldman Sachs',
      'CFA Charterholder',
      'Advised on £200M+ in tech transactions',
      'Expert in startup financial modeling',
    ],
    bio: 'Finance professional with deep tech sector knowledge. Specializes in fundraising, financial strategy, and investor relations.',
  },
];

export function TeamSection() {
  return (
    <section id="team" className="relative py-24 bg-gradient-to-b from-black to-[#0D0D0D]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">The Team</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            World-class team with proven track records at Google, Bumble, Deliveroo, and Goldman Sachs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {team.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg overflow-hidden hover:border-[#FF7A00] transition-all group"
            >
              <div className="md:flex">
                {/* Photo */}
                <div className="md:w-1/3 relative overflow-hidden">
                  <div className="aspect-square relative">
                    <ImageWithFallback
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                    {/* Hover Glow Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#FF7A00]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                {/* Content */}
                <div className="md:w-2/3 p-8">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-white mb-1">{member.name}</h3>
                      <p className="text-[#FF7A00]">{member.role}</p>
                    </div>
                    <div className="flex gap-2">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        className="w-8 h-8 rounded-full bg-[#FF7A00]/10 flex items-center justify-center hover:bg-[#FF7A00]/20 transition-all"
                      >
                        <Linkedin className="w-4 h-4 text-[#FF7A00]" />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        className="w-8 h-8 rounded-full bg-[#FF7A00]/10 flex items-center justify-center hover:bg-[#FF7A00]/20 transition-all"
                      >
                        <Mail className="w-4 h-4 text-[#FF7A00]" />
                      </motion.button>
                    </div>
                  </div>

                  <p className="text-gray-400 text-sm mb-4">{member.bio}</p>

                  <div className="space-y-2">
                    {member.credentials.map((cred, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm text-gray-500">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#FF7A00] mt-1.5 flex-shrink-0" />
                        <span>{cred}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Team Strength Summary */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 bg-gradient-to-r from-[#FF7A00]/20 to-transparent border-2 border-[#FF7A00] rounded-lg p-8 max-w-4xl mx-auto"
        >
          <h3 className="text-white mb-6 text-center">Why This Team Will Win</h3>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div className="text-center">
              <div className="mb-3 text-[#FF7A00]" style={{ fontSize: '2rem', fontWeight: 'bold' }}>30+</div>
              <p className="text-gray-300">Combined years in tech & growth</p>
            </div>
            <div className="text-center">
              <div className="mb-3 text-[#FF7A00]" style={{ fontSize: '2rem', fontWeight: 'bold' }}>£200M+</div>
              <p className="text-gray-300">Transaction value advised on</p>
            </div>
            <div className="text-center">
              <div className="mb-3 text-[#FF7A00]" style={{ fontSize: '2rem', fontWeight: 'bold' }}>2M+</div>
              <p className="text-gray-300">Users scaled at previous companies</p>
            </div>
          </div>
          <p className="text-gray-400 text-center mt-6">
            Complementary skill sets across technology, growth, operations, and finance. Battle-tested at world-class companies. Ready to execute.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
