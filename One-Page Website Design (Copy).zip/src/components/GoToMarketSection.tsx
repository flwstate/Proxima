import { motion } from 'motion/react';
import { MapPin, TrendingUp, Globe, Heart, GraduationCap, Phone } from 'lucide-react';

const phases = [
  {
    number: 1,
    title: 'Foundation & Verification',
    subtitle: 'London Launch',
    timeline: 'Months 1-6',
    color: '#FF7A00',
    goals: [
      'Launch in Central London (targeted neighborhoods)',
      'Achieve 10,000 verified users',
      'Build trust through mental health partnerships',
      'Establish verification-first brand identity',
    ],
    tactics: [
      'University partnerships (UCL, LSE, Imperial)',
      'Influencer seeding in Shoreditch, Soho, Camden',
      'Mental health organization collaborations',
      'PR campaign: "London\'s safest social app"',
    ],
  },
  {
    number: 2,
    title: 'Education & Validation',
    subtitle: 'UK Expansion',
    timeline: 'Months 7-12',
    color: '#FF8C1A',
    goals: [
      'Expand to Manchester, Birmingham, Edinburgh',
      'Reach 100,000 active users',
      'Prove B2B Zones model with 50 venues',
      'Achieve 15% M-o-M growth',
    ],
    tactics: [
      'City-by-city rollout with local ambassadors',
      'University expansion program',
      'Corporate pilot programs (WeWork, Google Campus)',
      'Event partnerships (festivals, conferences)',
    ],
  },
  {
    number: 3,
    title: 'Scale Through Trust',
    subtitle: 'International Expansion',
    timeline: 'Months 13-24',
    color: '#FF9E33',
    goals: [
      'Launch in Dublin, Amsterdam, Paris, Berlin',
      'Scale to 1M users across Europe',
      'Enterprise Zones partnerships',
      'Series A fundraise (£5-8M)',
    ],
    tactics: [
      'Market-by-market localization',
      'Strategic partnerships with European universities',
      'B2B enterprise sales team',
      'International PR and growth marketing',
    ],
  },
];

const partners = [
  { name: 'Mind.org', type: 'Mental Health', logo: Heart },
  { name: 'Student Minds', type: 'University', logo: GraduationCap },
  { name: 'Nightline', type: 'Support', logo: Phone },
  { name: 'Young Minds', type: 'Youth', logo: Heart },
  { name: 'UCL', type: 'Education', logo: GraduationCap },
  { name: 'Imperial College', type: 'Education', logo: GraduationCap },
];

export function GoToMarketSection() {
  return (
    <section className="relative py-24 bg-gradient-to-b from-black to-[#0D0D0D]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Go-To-Market Strategy</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Methodical expansion focused on trust, verification, and community-driven growth
          </p>
        </motion.div>

        {/* Three-Phase Timeline */}
        <div className="relative max-w-6xl mx-auto mb-20">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-1 bg-gradient-to-r from-[#FF7A00] via-[#FF8C1A] to-[#FF9E33]" />

          <div className="grid lg:grid-cols-3 gap-8">
            {phases.map((phase, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="relative"
              >
                {/* Phase Number Badge */}
                <motion.div
                  className="w-16 h-16 rounded-full flex items-center justify-center text-2xl mx-auto mb-6 border-4 border-black relative z-10"
                  style={{
                    backgroundColor: phase.color,
                    color: 'white',
                  }}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.2 }}
                  whileHover={{ scale: 1.1 }}
                >
                  {phase.number}
                </motion.div>

                {/* Phase Card */}
                <div
                  className="bg-gradient-to-br from-black to-[#0D0D0D] border-2 rounded-lg p-8 hover:border-[#FF7A00] transition-all"
                  style={{ borderColor: `${phase.color}50` }}
                >
                  <div className="text-center mb-6">
                    <h3 className="text-white mb-2">{phase.title}</h3>
                    <p style={{ color: phase.color }} className="mb-2">{phase.subtitle}</p>
                    <p className="text-gray-500 text-sm">{phase.timeline}</p>
                  </div>

                  <div className="mb-6">
                    <h4 className="text-white text-sm mb-3">Key Goals:</h4>
                    <ul className="space-y-2">
                      {phase.goals.map((goal, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-400">
                          <div
                            className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                            style={{ backgroundColor: phase.color }}
                          />
                          <span>{goal}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-white text-sm mb-3">Tactics:</h4>
                    <ul className="space-y-2">
                      {phase.tactics.map((tactic, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-500">
                          <span className="text-[#FF7A00] mt-0.5">→</span>
                          <span>{tactic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Strategic Partnerships */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-8 text-white">Strategic Partnership Network</h3>
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
            {partners.map((partner, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6 text-center hover:border-[#FF7A00] transition-all group"
              >
                <motion.div
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#FF7A00]/10 mb-3 group-hover:bg-[#FF7A00]/20 transition-all"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <partner.logo className="w-6 h-6 text-[#FF7A00]" />
                </motion.div>
                <h4 className="text-white text-sm mb-1">{partner.name}</h4>
                <p className="text-xs text-gray-500">{partner.type}</p>
              </motion.div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-8 rounded-r-lg">
            <h4 className="text-white mb-4">Why Partnerships Matter</h4>
            <div className="grid md:grid-cols-3 gap-6 text-sm">
              <div>
                <div className="flex items-center gap-2 mb-2 text-[#FF7A00]">
                  <Heart className="w-5 h-5" />
                  <span>Trust Building</span>
                </div>
                <p className="text-gray-400">
                  Mental health partnerships establish Proxima as a force for good, not just another social app.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2 text-[#FF7A00]">
                  <GraduationCap className="w-5 h-5" />
                  <span>User Acquisition</span>
                </div>
                <p className="text-gray-400">
                  University collaborations provide access to ideal early adopters with high network density.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2 text-[#FF7A00]">
                  <Globe className="w-5 h-5" />
                  <span>Credibility</span>
                </div>
                <p className="text-gray-400">
                  Association with respected institutions differentiates Proxima from competitors.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Growth Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-8"
        >
          <h3 className="text-center mb-8 text-white">24-Month Growth Projections</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { metric: 'Total Users', value: '1M+', icon: MapPin },
              { metric: 'Monthly Active', value: '650K+', icon: TrendingUp },
              { metric: 'Verified Accounts', value: '850K+', icon: Heart },
              { metric: 'B2B Venues', value: '500+', icon: Globe },
            ].map((item, i) => (
              <div key={i} className="text-center p-6 bg-black/50 border border-[#FF7A00]/30 rounded-lg">
                <item.icon className="w-8 h-8 text-[#FF7A00] mx-auto mb-3" />
                <div className="mb-2 text-[#FF7A00]" style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                  {item.value}
                </div>
                <p className="text-gray-400 text-sm">{item.metric}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
