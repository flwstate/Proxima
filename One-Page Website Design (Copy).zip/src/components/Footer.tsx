import { motion } from 'motion/react';
import { Mail, Linkedin, Twitter, Instagram, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative bg-black border-t border-[#FF7A00]/30 py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Logo & Tagline */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h3 className="text-white mb-3">Proxima</h3>
              <p className="text-gray-400 text-sm mb-4">
                The Future of Meaningful Connection
              </p>
              <div className="flex items-center gap-2 text-gray-500 text-sm">
                <MapPin className="w-4 h-4" />
                <span>London, United Kingdom</span>
              </div>
            </motion.div>
          </div>

          {/* Product */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <h4 className="text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                {['Features', 'Pricing', 'For Businesses', 'Safety', 'Download'].map((item, i) => (
                  <li key={i}>
                    <a href="#" className="text-gray-400 hover:text-[#FF7A00] transition-colors">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>

          {/* Company */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h4 className="text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                {['About Us', 'Team', 'Careers', 'Press Kit', 'Investors'].map((item, i) => (
                  <li key={i}>
                    <a href="#" className="text-gray-400 hover:text-[#FF7A00] transition-colors">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>

          {/* Legal */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <h4 className="text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'GDPR Compliance', 'Security'].map((item, i) => (
                  <li key={i}>
                    <a href="#" className="text-gray-400 hover:text-[#FF7A00] transition-colors">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>

        {/* Social & Copyright */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="pt-8 border-t border-[#FF7A00]/30 flex flex-col md:flex-row items-center justify-between gap-4"
        >
          <div className="text-gray-500 text-sm">
            © 2025 Proxima. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            {[
              { icon: Mail, label: 'Email' },
              { icon: Linkedin, label: 'LinkedIn' },
              { icon: Twitter, label: 'Twitter' },
              { icon: Instagram, label: 'Instagram' },
            ].map((social, i) => (
              <motion.a
                key={i}
                href="#"
                whileHover={{ scale: 1.1, y: -2 }}
                className="w-10 h-10 rounded-full bg-[#FF7A00]/10 border border-[#FF7A00]/30 flex items-center justify-center hover:bg-[#FF7A00]/20 hover:border-[#FF7A00] transition-all group"
                aria-label={social.label}
              >
                <social.icon className="w-5 h-5 text-gray-400 group-hover:text-[#FF7A00] transition-colors" />
              </motion.a>
            ))}
          </div>

          <div className="text-gray-500 text-sm">
            contact@proxima.app
          </div>
        </motion.div>

        {/* Bottom Tagline */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-8 text-center"
        >
          <p className="text-gray-600 text-xs">
            Building the future of meaningful connection, one proximity at a time.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
