import { motion } from 'motion/react';
import { Radar, Wifi, Bluetooth, Radio, Compass, Gauge } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const aiModels = [
  { number: 1, title: 'Sensor Fusion Engine', description: 'Combines GPS, Wi-Fi, BLE, UWB, IMU, and barometric data for precision positioning' },
  { number: 2, title: 'Proximity Detection System', description: 'Real-time distance calculation and zone classification with <1m accuracy' },
  { number: 3, title: 'Context Recognition AI', description: 'Understands environmental context (indoor/outdoor, venue type, activity)' },
  { number: 4, title: 'Privacy Filtering Layer', description: 'On-device processing ensures sensitive location data never leaves your phone' },
  { number: 5, title: 'Match Orchestration Engine', description: 'Coordinates proximity, personality, and context for optimal recommendations' },
  { number: 6, title: 'Intelligence Layer', description: 'Adaptive learning system that improves matching accuracy over time' },
];

const sensors = [
  { name: 'GPS', icon: Radar, description: 'Satellite positioning', accuracy: '~5m' },
  { name: 'Wi-Fi', icon: Wifi, description: 'Indoor positioning', accuracy: '~3m' },
  { name: 'BLE', icon: Bluetooth, description: 'Bluetooth Low Energy', accuracy: '~1m' },
  { name: 'UWB', icon: Radio, description: 'Ultra-Wideband', accuracy: '<1m' },
  { name: 'IMU', icon: Compass, description: 'Motion tracking', accuracy: 'Direction' },
  { name: 'Barometer', icon: Gauge, description: 'Floor detection', accuracy: 'Altitude' },
];

const proximityZones = [
  { name: 'Immediate', range: '0-5m', color: '#FF7A00', description: 'Same room / table' },
  { name: 'Nearby', range: '5-25m', color: '#FF8C1A', description: 'Same venue' },
  { name: 'Local', range: '25-100m', color: '#FF9E33', description: 'Same block' },
  { name: 'District', range: '100m-1km', color: '#FFB04D', description: 'Neighborhood' },
];

export function UnderTheHoodSection() {
  return (
    <section id="features" className="relative py-24 bg-black overflow-hidden">
      {/* Circuit Background */}
      <div className="absolute inset-0 opacity-5">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1754603957757-52cbda751ea9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHRlY2hub2xvZ3klMjBjaXJjdWl0fGVufDF8fHx8MTc2MDk2MjE0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Circuit"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Animated Circuit Lines */}
      <div className="absolute inset-0">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-[#FF7A00]"
            style={{
              width: Math.random() > 0.5 ? '100%' : '2px',
              height: Math.random() > 0.5 ? '2px' : '100%',
              left: Math.random() > 0.5 ? 0 : `${Math.random() * 100}%`,
              top: Math.random() > 0.5 ? `${Math.random() * 100}%` : 0,
              opacity: 0.1,
            }}
            animate={{
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Under the Hood – AI Processing Core</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Six AI models work in concert to deliver unprecedented proximity intelligence and matching precision
          </p>
        </motion.div>

        {/* AI Models Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {aiModels.map((model, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-6 hover:border-[#FF7A00] transition-all group"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-[#FF7A00]/20 flex items-center justify-center text-[#FF7A00] border border-[#FF7A00] group-hover:shadow-[0_0_15px_#FF7A00] transition-all">
                  #{model.number}
                </div>
                <h3 className="text-white">{model.title}</h3>
              </div>
              <p className="text-gray-400 text-sm">{model.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Sensors Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <h3 className="text-center mb-8 text-white">Sensor Fusion Technology</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {sensors.map((sensor, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4 text-center hover:border-[#FF7A00] transition-all group"
              >
                <motion.div
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#FF7A00]/10 mb-3 group-hover:bg-[#FF7A00]/20 transition-all"
                  whileHover={{ rotate: 360, scale: 1.1 }}
                  transition={{ duration: 0.6 }}
                >
                  <sensor.icon className="w-6 h-6 text-[#FF7A00]" />
                </motion.div>
                <h4 className="text-white mb-1">{sensor.name}</h4>
                <p className="text-xs text-gray-400 mb-1">{sensor.description}</p>
                <p className="text-xs text-[#FF7A00]">{sensor.accuracy}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Proximity Zones Radial Diagram */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-8 text-white">4 Proximity Zones</h3>
          <div className="max-w-4xl mx-auto">
            {/* Radial Visualization */}
            <div className="relative aspect-square max-w-lg mx-auto mb-8">
              {proximityZones.map((zone, index) => {
                const size = 100 - index * 20;
                return (
                  <motion.div
                    key={index}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 flex items-center justify-center"
                    style={{
                      width: `${size}%`,
                      height: `${size}%`,
                      borderColor: zone.color,
                      backgroundColor: `${zone.color}10`,
                    }}
                    initial={{ scale: 0, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.2 }}
                    whileHover={{ scale: 1.05 }}
                  >
                    {index === 0 && (
                      <div className="text-center">
                        <div className="w-12 h-12 rounded-full bg-[#FF7A00] mx-auto mb-2 shadow-[0_0_30px_#FF7A00]" />
                        <p className="text-xs text-white">You</p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* Zone Legend */}
            <div className="grid md:grid-cols-4 gap-4">
              {proximityZones.map((zone, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="text-center p-4 bg-black/50 border border-[#FF7A00]/30 rounded-lg"
                >
                  <div
                    className="w-4 h-4 rounded-full mx-auto mb-2"
                    style={{ backgroundColor: zone.color, boxShadow: `0 0 10px ${zone.color}` }}
                  />
                  <h4 className="text-white mb-1">{zone.name}</h4>
                  <p className="text-xs" style={{ color: zone.color }}>{zone.range}</p>
                  <p className="text-xs text-gray-400 mt-1">{zone.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
