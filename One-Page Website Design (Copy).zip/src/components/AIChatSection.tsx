import { motion } from 'motion/react';
import { Sparkles, MessageSquare, BarChart3, TrendingUp, ThumbsUp, Heart, Share2 } from 'lucide-react';

const pillar1Features = [
  { title: 'Smart Starters', description: 'AI generates personalized conversation openers based on shared interests', icon: MessageSquare },
  { title: 'Mood Analysis', description: 'Real-time sentiment detection helps you understand conversation tone', icon: BarChart3 },
  { title: 'Flow Mapping', description: 'Visualize conversation patterns and suggest optimal engagement times', icon: TrendingUp },
];

const pillar2Features = [
  { title: 'Integrated Posts', description: 'Share updates, photos, and moments with your proximity network', icon: Share2 },
  { title: 'Likes & Reactions', description: 'Express yourself with rich emoji reactions and engagement', icon: ThumbsUp },
  { title: 'Social Feed', description: 'Discover content from people and places around you', icon: Heart },
];

export function AIChatSection() {
  return (
    <section className="relative py-24 bg-gradient-to-b from-black to-[#0D0D0D]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">AI-Powered Chat Feature</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Two intelligent pillars working together to create meaningful, engaging conversations
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Pillar 1: Conversation Intelligence */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-gradient-to-br from-[#FF7A00]/20 to-transparent border-2 border-[#FF7A00] rounded-lg p-8 h-full">
              <div className="flex items-center gap-3 mb-6">
                <motion.div
                  className="w-12 h-12 rounded-full bg-[#FF7A00] flex items-center justify-center"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                >
                  <Sparkles className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <h3 className="text-white">Pillar 1</h3>
                  <p className="text-[#FF7A00]">Conversation Intelligence Engine</p>
                </div>
              </div>

              <div className="space-y-6">
                {pillar1Features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6 hover:border-[#FF7A00] transition-all group"
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#FF7A00]/20 flex items-center justify-center group-hover:bg-[#FF7A00]/30 transition-all">
                        <feature.icon className="w-5 h-5 text-[#FF7A00]" />
                      </div>
                      <div>
                        <h4 className="text-white mb-2">{feature.title}</h4>
                        <p className="text-gray-400 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Example AI Starter */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-6 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-4 rounded-r-lg"
              >
                <div className="flex items-start gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-[#FF7A00] mt-1 flex-shrink-0" />
                  <p className="text-sm text-gray-300">
                    <span className="text-[#FF7A00]">AI Suggestion:</span> "I noticed you both love hiking! Have you tried the trail in Richmond Park?"
                  </p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Pillar 2: Social Media Layer */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-gradient-to-br from-[#FF7A00]/20 to-transparent border-2 border-[#FF7A00] rounded-lg p-8 h-full">
              <div className="flex items-center gap-3 mb-6">
                <motion.div
                  className="w-12 h-12 rounded-full bg-[#FF7A00] flex items-center justify-center"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Heart className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <h3 className="text-white">Pillar 2</h3>
                  <p className="text-[#FF7A00]">Integrated Social Media Layer</p>
                </div>
              </div>

              <div className="space-y-6">
                {pillar2Features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6 hover:border-[#FF7A00] transition-all group"
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#FF7A00]/20 flex items-center justify-center group-hover:bg-[#FF7A00]/30 transition-all">
                        <feature.icon className="w-5 h-5 text-[#FF7A00]" />
                      </div>
                      <div>
                        <h4 className="text-white mb-2">{feature.title}</h4>
                        <p className="text-gray-400 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Sample Social Post */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-6 bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#FF8C1A]" />
                  <div>
                    <p className="text-white text-sm">Alex Chen</p>
                    <p className="text-gray-500 text-xs">5m ago · Nearby</p>
                  </div>
                </div>
                <p className="text-gray-300 text-sm mb-3">
                  Just discovered this amazing coffee spot! Who wants to join? ☕️
                </p>
                <div className="flex items-center gap-4 text-gray-400 text-xs">
                  <button className="flex items-center gap-1 hover:text-[#FF7A00] transition-colors">
                    <Heart className="w-4 h-4" />
                    <span>24</span>
                  </button>
                  <button className="flex items-center gap-1 hover:text-[#FF7A00] transition-colors">
                    <MessageSquare className="w-4 h-4" />
                    <span>7</span>
                  </button>
                  <button className="flex items-center gap-1 hover:text-[#FF7A00] transition-colors">
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Animated Message Bubbles with AI Spark */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 max-w-4xl mx-auto"
        >
          <h3 className="text-center mb-8 text-white">AI-Enhanced Messaging in Action</h3>
          <div className="bg-gradient-to-b from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-8">
            <div className="space-y-4">
              {/* User Message */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4 }}
                className="flex justify-end"
              >
                <div className="bg-[#FF7A00] rounded-2xl rounded-tr-sm px-4 py-3 max-w-xs">
                  <p className="text-white text-sm">Hey! I saw we're both at this event. Love your energy!</p>
                </div>
              </motion.div>

              {/* AI Suggestion */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.2 }}
                className="flex justify-center"
              >
                <div className="flex items-center gap-2 bg-[#FF7A00]/10 border border-[#FF7A00]/30 rounded-full px-4 py-2">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  >
                    <Sparkles className="w-4 h-4 text-[#FF7A00]" />
                  </motion.div>
                  <span className="text-xs text-gray-400">AI analyzing conversation tone... Positive match!</span>
                </div>
              </motion.div>

              {/* Response */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.4 }}
                className="flex justify-start"
              >
                <div className="bg-[#1A1A1A] border border-[#FF7A00]/30 rounded-2xl rounded-tl-sm px-4 py-3 max-w-xs">
                  <p className="text-white text-sm">Thanks! Are you interested in the tech workshop later?</p>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
