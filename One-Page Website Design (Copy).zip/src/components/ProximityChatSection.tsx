import { motion } from 'motion/react';
import { MessageCircle, Users, MapPin, Building } from 'lucide-react';

const proximityRings = [
  { name: 'Immediate', range: '0-5m', color: '#FF7A00', users: 12, description: 'People at your table' },
  { name: 'Nearby', range: '5-25m', color: '#FF8C1A', users: 47, description: 'People in this venue' },
  { name: 'Local', range: '25-100m', color: '#FF9E33', users: 156, description: 'People on this street' },
  { name: 'District', range: '100m-1km', color: '#FFB04D', users: 892, description: 'People in your area' },
];

const chatMessages = [
  { user: 'Sarah', message: 'Anyone want to grab coffee? ☕', zone: 'Nearby', time: '2m ago' },
  { user: 'Alex', message: 'New to the area, looking for gym recommendations', zone: 'Local', time: '5m ago' },
  { user: 'Jamie', message: 'Tech meetup starting in 30 mins!', zone: 'District', time: '12m ago' },
];

export function ProximityChatSection() {
  return (
    <section className="relative py-24 bg-black">
      {/* Radar Animation Background */}
      <div className="absolute inset-0 overflow-hidden opacity-10">
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ width: '800px', height: '800px' }}
        >
          {[...Array(4)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute inset-0 border-2 border-[#FF7A00] rounded-full"
              initial={{ scale: 0, opacity: 1 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.75,
              }}
            />
          ))}
        </motion.div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Proximity Chat – Discord on the Go</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Join location-based chat rooms that adapt to your proximity. Connect with people around you in real-time.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Proximity Rings Visualization */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="mb-8 text-white text-center">Proximity Zones</h3>
            
            {/* Radial Ring Display */}
            <div className="relative aspect-square max-w-md mx-auto mb-8">
              {proximityRings.map((ring, index) => {
                const size = 100 - index * 20;
                return (
                  <motion.div
                    key={index}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2"
                    style={{
                      width: `${size}%`,
                      height: `${size}%`,
                      borderColor: ring.color,
                      backgroundColor: `${ring.color}08`,
                    }}
                    initial={{ scale: 0, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.15 }}
                  >
                    {/* User Count Pulse */}
                    {index === 0 && (
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                        <motion.div
                          className="w-16 h-16 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: ring.color, boxShadow: `0 0 30px ${ring.color}` }}
                          animate={{ scale: [1, 1.1, 1] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          <Users className="w-8 h-8 text-white" />
                        </motion.div>
                      </div>
                    )}
                  </motion.div>
                );
              })}

              {/* Sound Wave Lines */}
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute top-1/2 left-1/2 w-1 bg-[#FF7A00] origin-left"
                  style={{
                    height: '2px',
                    transform: `rotate(${i * 45}deg)`,
                  }}
                  animate={{
                    scaleX: [0.5, 1, 0.5],
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: i * 0.125,
                  }}
                />
              ))}
            </div>

            {/* Zone Details */}
            <div className="space-y-3">
              {proximityRings.map((ring, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4 hover:border-[#FF7A00] transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: ring.color, boxShadow: `0 0 10px ${ring.color}` }}
                      />
                      <div>
                        <h4 className="text-white">{ring.name}</h4>
                        <p className="text-xs text-gray-400">{ring.range}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[#FF7A00]">{ring.users}</div>
                      <p className="text-xs text-gray-400">users</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">{ring.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: Chat UI Mock */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="mb-8 text-white text-center">Live Chat Interface</h3>

            {/* Chat Header */}
            <div className="bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A] rounded-t-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-white" />
                  <div>
                    <h4 className="text-white">Shoreditch District</h4>
                    <p className="text-white/80 text-sm">892 people nearby</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <motion.div
                    className="w-2 h-2 bg-green-400 rounded-full"
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="text-white text-sm">Live</span>
                </div>
              </div>
            </div>

            {/* Chat Messages */}
            <div className="bg-gradient-to-b from-black to-[#0D0D0D] border-x border-[#FF7A00]/30 p-6 space-y-4" style={{ minHeight: '400px' }}>
              {chatMessages.map((msg, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.2 }}
                  className="bg-black/50 border border-[#FF7A00]/20 rounded-lg p-4 hover:border-[#FF7A00]/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#FF8C1A]" />
                      <span className="text-white">{msg.user}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-[#FF7A00]/20 text-[#FF7A00] border border-[#FF7A00]/30">
                        {msg.zone}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">{msg.time}</span>
                  </div>
                  <p className="text-gray-300">{msg.message}</p>
                </motion.div>
              ))}

              {/* Typing Indicator */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="flex items-center gap-2 text-gray-500 text-sm"
              >
                <div className="flex gap-1">
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-2 h-2 bg-[#FF7A00] rounded-full"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{
                        duration: 1,
                        repeat: Infinity,
                        delay: i * 0.2,
                      }}
                    />
                  ))}
                </div>
                <span>3 people typing...</span>
              </motion.div>
            </div>

            {/* Chat Input */}
            <div className="bg-black border border-[#FF7A00]/30 rounded-b-lg p-4">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  placeholder="Send a message to nearby users..."
                  className="flex-1 bg-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-[#FF7A00]"
                />
                <button className="px-6 py-2 bg-[#FF7A00] hover:bg-[#FF8C1A] text-white rounded-lg transition-colors">
                  <MessageCircle className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
