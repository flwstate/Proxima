import { useState } from 'motion/react';
import { motion } from 'motion/react';
import { Users, Building, Crown, Zap, Camera, MapPin, TrendingUp, Target, DollarSign, BarChart3 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const b2cStreams = [
  {
    title: 'Premium Subscriptions',
    icon: Crown,
    tiers: ['Free', 'Plus (£9.99/mo)', 'Pro (£19.99/mo)'],
    features: ['Unlimited waves', 'Advanced filters', 'Priority matching', 'AR features'],
  },
  {
    title: 'In-App Purchases',
    icon: Zap,
    items: ['Boost visibility', 'Super waves', 'Profile highlights', 'Event promotions'],
  },
  {
    title: 'AR Premiums',
    icon: Camera,
    items: ['Custom AR filters', 'Virtual gifts', 'Enhanced overlays', 'Premium badges'],
  },
];

const b2bStreams = [
  {
    title: 'Proxima Zones',
    icon: MapPin,
    pricing: '£299-£999/month per location',
    description: 'Location-based user engagement for businesses',
  },
  {
    title: 'Event Partnerships',
    icon: Target,
    pricing: 'Commission-based',
    description: 'Event discovery and ticketing integration',
  },
  {
    title: 'Brand Collaborations',
    icon: Building,
    pricing: 'Custom packages',
    description: 'Sponsored content and brand activations',
  },
  {
    title: 'Data Licensing',
    icon: BarChart3,
    pricing: 'Enterprise contracts',
    description: 'Anonymized foot traffic and trend insights',
  },
];

const revenueData = [
  { name: 'Premium Subs', value: 35, color: '#FF7A00' },
  { name: 'Proxima Zones', value: 30, color: '#FF8C1A' },
  { name: 'In-App Purchases', value: 15, color: '#FF9E33' },
  { name: 'Event Partnerships', value: 10, color: '#FFB04D' },
  { name: 'Brand Collaborations', value: 7, color: '#FFC266' },
  { name: 'Data Licensing', value: 3, color: '#FFD480' },
];

export function MonetizationSection() {
  return (
    <section className="relative py-24 bg-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Monetization Ecosystem</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Diversified revenue streams across consumer and enterprise markets
          </p>
        </motion.div>

        <Tabs defaultValue="b2c" className="max-w-6xl mx-auto">
          <TabsList className="grid w-full grid-cols-2 mb-12 bg-black/50 border border-[#FF7A00]/30">
            <TabsTrigger value="b2c" className="data-[state=active]:bg-[#FF7A00] data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              B2C Revenue
            </TabsTrigger>
            <TabsTrigger value="b2b" className="data-[state=active]:bg-[#FF7A00] data-[state=active]:text-white">
              <Building className="w-4 h-4 mr-2" />
              B2B / Enterprise
            </TabsTrigger>
          </TabsList>

          <TabsContent value="b2c">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <div className="grid md:grid-cols-3 gap-6">
                {b2cStreams.map((stream, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-6 hover:border-[#FF7A00] transition-all group"
                  >
                    <motion.div
                      className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#FF7A00]/10 mb-6 group-hover:bg-[#FF7A00]/20 transition-all"
                      whileHover={{ scale: 1.1, rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <stream.icon className="w-7 h-7 text-[#FF7A00]" />
                    </motion.div>

                    <h3 className="text-white mb-4">{stream.title}</h3>

                    {'tiers' in stream && (
                      <div className="space-y-2">
                        {stream.tiers.map((tier, i) => (
                          <div key={i} className="bg-black/50 border border-[#FF7A00]/20 rounded px-3 py-2 text-sm text-gray-300">
                            {tier}
                          </div>
                        ))}
                        <div className="mt-4 pt-4 border-t border-[#FF7A00]/30">
                          <p className="text-xs text-gray-500 mb-2">Features:</p>
                          <div className="space-y-1">
                            {stream.features.map((feature, i) => (
                              <div key={i} className="flex items-center gap-2 text-xs text-gray-400">
                                <div className="w-1 h-1 rounded-full bg-[#FF7A00]" />
                                <span>{feature}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {'items' in stream && (
                      <div className="space-y-2">
                        {stream.items.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-sm text-gray-400">
                            <DollarSign className="w-4 h-4 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mt-8 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-6 rounded-r-lg"
              >
                <h4 className="text-white mb-3">Freemium Model Strategy</h4>
                <p className="text-gray-300 text-sm mb-3">
                  Free tier drives user acquisition and network effects. Premium features unlock enhanced discovery, visibility, and engagement capabilities. Target 8-12% conversion to paid within 6 months.
                </p>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">Year 1 Target</div>
                    <div className="text-white">50K users → 5K paying</div>
                  </div>
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">ARPU</div>
                    <div className="text-white">£14.99/month</div>
                  </div>
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">LTV:CAC</div>
                    <div className="text-white">4.2:1</div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </TabsContent>

          <TabsContent value="b2b">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <div className="grid md:grid-cols-2 gap-6">
                {b2bStreams.map((stream, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-8 hover:border-[#FF7A00] transition-all group"
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <motion.div
                        className="flex-shrink-0 w-14 h-14 rounded-full bg-[#FF7A00]/10 flex items-center justify-center group-hover:bg-[#FF7A00]/20 transition-all"
                        whileHover={{ scale: 1.1, rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        <stream.icon className="w-7 h-7 text-[#FF7A00]" />
                      </motion.div>
                      <div className="flex-1">
                        <h3 className="text-white mb-2">{stream.title}</h3>
                        <p className="text-[#FF7A00] text-sm">{stream.pricing}</p>
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm">{stream.description}</p>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-8 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-6 rounded-r-lg"
              >
                <h4 className="text-white mb-3">B2B Growth Strategy</h4>
                <p className="text-gray-300 text-sm mb-4">
                  Target high-footfall venues in London first: cafés, coworking spaces, event venues, retail stores. Expansion to universities, conferences, and enterprise campuses in Year 2.
                </p>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">Year 1 Target</div>
                    <div className="text-white">50 venues × £499/mo</div>
                  </div>
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">MRR Potential</div>
                    <div className="text-white">£24,950/month</div>
                  </div>
                  <div className="bg-black/50 border border-[#FF7A00]/30 rounded p-3">
                    <div className="text-[#FF7A00] mb-1">Churn Rate</div>
                    <div className="text-white">&lt; 5%</div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </TabsContent>
        </Tabs>

        {/* Revenue Split Chart */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-20"
        >
          <h3 className="text-center mb-12 text-white">Projected Revenue Mix (Year 3)</h3>
          <div className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={revenueData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                    >
                      {revenueData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0D0D0D',
                        border: '1px solid #FF7A00',
                        borderRadius: '8px',
                        color: '#fff',
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-4">
                {revenueData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-black/50 border border-[#FF7A00]/20 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-white">{item.name}</span>
                    </div>
                    <span className="text-[#FF7A00]">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
