import { motion } from 'motion/react';
import { Store, Settings, Users as UsersIcon, BarChart3, Shield, Eye, Award } from 'lucide-react';

const dashboardFeatures = [
  {
    title: 'Define Zone',
    icon: Store,
    description: 'Set geographical boundaries for your business location with precision mapping',
    metrics: ['Custom radius', 'Multi-location support', 'Floor-level targeting'],
  },
  {
    title: 'Customize Experience',
    icon: Settings,
    description: 'Create branded experiences, offers, and content for users entering your zone',
    metrics: ['Custom messaging', 'Promotional content', 'Brand integration'],
  },
  {
    title: 'Engage Users',
    icon: UsersIcon,
    description: 'Send targeted notifications, offers, and interactions to nearby Proxima users',
    metrics: ['Push notifications', 'In-app messaging', 'Gamification'],
  },
  {
    title: 'Analyze Data',
    icon: BarChart3,
    description: 'Track foot traffic, engagement rates, conversion metrics, and ROI in real-time',
    metrics: ['Visitor analytics', 'Engagement rates', 'Revenue tracking'],
  },
];

const userExperienceFeatures = [
  { title: 'Consent', description: 'Users opt-in to receive zone notifications', icon: Shield },
  { title: 'Control', description: 'Full control over which zones can reach them', icon: Settings },
  { title: 'Value', description: 'Only receive relevant, personalized offers', icon: Award },
];

export function ZonesSection() {
  return (
    <section className="relative py-24 bg-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Proxima Zones – For Businesses</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Transform your physical location into an intelligent engagement hub. Connect with nearby customers in real-time.
          </p>
        </motion.div>

        {/* Dashboard Preview */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="bg-gradient-to-br from-[#0D0D0D] to-black border-2 border-[#FF7A00]/30 rounded-lg overflow-hidden">
            {/* Dashboard Header */}
            <div className="bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A] p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-white mb-1">Zones Dashboard</h3>
                  <p className="text-white/80 text-sm">Real-time business intelligence</p>
                </div>
                <div className="flex items-center gap-6 text-white">
                  <div className="text-right">
                    <div className="text-sm opacity-80">Active Users</div>
                    <div className="text-2xl">487</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm opacity-80">Engagement Rate</div>
                    <div className="text-2xl">23.4%</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Dashboard Content */}
            <div className="p-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {dashboardFeatures.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6 hover:border-[#FF7A00] transition-all group"
                  >
                    <motion.div
                      className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#FF7A00]/10 mb-4 group-hover:bg-[#FF7A00]/20 transition-all"
                      whileHover={{ scale: 1.1, rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <feature.icon className="w-6 h-6 text-[#FF7A00]" />
                    </motion.div>

                    <h4 className="text-white mb-3">{feature.title}</h4>
                    <p className="text-gray-400 text-sm mb-4">{feature.description}</p>

                    <div className="space-y-1">
                      {feature.metrics.map((metric, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-gray-500">
                          <div className="w-1 h-1 rounded-full bg-[#FF7A00]" />
                          <span>{metric}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Sample Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-8 bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6"
              >
                <h4 className="text-white mb-6">Foot Traffic Analytics</h4>
                <div className="flex items-end justify-between h-40 gap-2">
                  {[45, 67, 89, 78, 92, 85, 96].map((height, i) => (
                    <motion.div
                      key={i}
                      className="flex-1 bg-gradient-to-t from-[#FF7A00] to-[#FF8C1A] rounded-t"
                      initial={{ height: 0 }}
                      whileInView={{ height: `${height}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: i * 0.1 }}
                      whileHover={{ opacity: 0.8 }}
                    />
                  ))}
                </div>
                <div className="flex justify-between mt-4 text-xs text-gray-500">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                    <span key={i}>{day}</span>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* User Experience Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-8 text-white">User Experience: Consent, Control & Value</h3>
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {userExperienceFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-gradient-to-br from-[#FF7A00]/10 to-transparent border border-[#FF7A00]/30 rounded-lg p-8 text-center"
              >
                <motion.div
                  className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#FF7A00]/20 mb-4"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <feature.icon className="w-8 h-8 text-[#FF7A00]" />
                </motion.div>
                <h4 className="text-white mb-3">{feature.title}</h4>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-8 rounded-r-lg">
            <h4 className="text-white mb-4">Privacy-First Approach</h4>
            <p className="text-gray-300 mb-4">
              Proxima Zones respects user privacy. Businesses never see individual user data – only aggregated, anonymized analytics. Users maintain complete control over their visibility and notification preferences.
            </p>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-400">
              <div className="flex items-start gap-2">
                <Shield className="w-5 h-5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <span>End-to-end encrypted user data</span>
              </div>
              <div className="flex items-start gap-2">
                <Eye className="w-5 h-5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <span>Transparent data usage policies</span>
              </div>
              <div className="flex items-start gap-2">
                <Settings className="w-5 h-5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <span>Granular permission controls</span>
              </div>
              <div className="flex items-start gap-2">
                <Award className="w-5 h-5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <span>GDPR & CCPA compliant</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
