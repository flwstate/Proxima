import { motion } from 'motion/react';
import { Users, Smartphone, Heart, MessageSquare, MapPin, Shield } from 'lucide-react';
import { Card } from './ui/card';

const statistics = [
  { value: '45%', label: 'UK Adults Report Loneliness', icon: Users },
  { value: '93%', label: 'Smartphone Penetration', icon: Smartphone },
  { value: '31%', label: 'Young Adults Chronically Lonely', icon: Heart },
];

const problems = [
  {
    title: 'Rising Social Isolation',
    description: 'Despite hyperconnectivity, loneliness is at epidemic levels. Traditional social platforms fail to foster genuine, local connections.',
    icon: Users,
  },
  {
    title: 'Superficial Interactions',
    description: 'Dating apps focus on swipes, not substance. Professional networks lack personality. Social media breeds comparison, not community.',
    icon: MessageSquare,
  },
  {
    title: 'Missing Integration',
    description: 'Users juggle multiple apps for dating, networking, events, and local discovery. No single platform unifies these needs intelligently.',
    icon: MapPin,
  },
  {
    title: 'Underserved Impact',
    description: 'Mental health, professional growth, and local economies suffer from the absence of meaningful, proximity-based social infrastructure.',
    icon: Shield,
  },
];

export function ProblemSection() {
  return (
    <section id="problem" className="relative py-24 bg-gradient-to-b from-black to-[#0D0D0D]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Problem & Market Gaps</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto" />
        </motion.div>

        {/* Statistics Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {statistics.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="bg-black/50 border-[#FF7A00]/30 p-8 text-center hover:border-[#FF7A00] transition-all hover:shadow-[0_0_30px_rgba(255,122,0,0.3)] group">
                <motion.div
                  className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#FF7A00]/10 mb-4 group-hover:bg-[#FF7A00]/20 transition-all"
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <stat.icon className="w-8 h-8 text-[#FF7A00]" />
                </motion.div>
                <div className="mb-2 text-[#FF7A00]" style={{ fontSize: '3rem', fontWeight: 'bold' }}>{stat.value}</div>
                <p className="text-gray-300">{stat.label}</p>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Problem Details */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-black to-[#0D0D0D] border-[#FF7A00]/20 p-8 h-full hover:border-[#FF7A00] transition-all group">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-[#FF7A00]/10 flex items-center justify-center group-hover:bg-[#FF7A00]/20 transition-all">
                    <problem.icon className="w-6 h-6 text-[#FF7A00]" />
                  </div>
                  <div>
                    <h3 className="mb-3 text-white">{problem.title}</h3>
                    <p className="text-gray-400">{problem.description}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Comparison Infographic */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-r from-black via-[#0D0D0D] to-black border border-[#FF7A00]/30 rounded-lg p-8"
        >
          <h3 className="text-center mb-8 text-white">Current Platforms vs Proxima</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="mb-4 text-gray-400">Current Platforms</h4>
              <ul className="space-y-3">
                {[
                  'Fragmented experience across multiple apps',
                  'Surface-level matching algorithms',
                  'No real-time proximity awareness',
                  'Privacy concerns and data exploitation',
                  'Limited professional networking integration',
                  'Disconnected from local communities'
                ].map((item, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-start gap-2 text-red-400"
                  >
                    <span className="text-red-500 mt-1">✗</span>
                    <span>{item}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="mb-4 text-[#FF7A00]">Proxima</h4>
              <ul className="space-y-3">
                {[
                  'All-in-one unified platform',
                  'Deep personality & compatibility matching',
                  'Precision proximity with 6-layer AI',
                  'Privacy-first, GDPR-compliant design',
                  'Seamless social + professional networking',
                  'Hyper-local community engagement'
                ].map((item, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-start gap-2 text-[#FF7A00]"
                  >
                    <span className="text-green-500 mt-1">✓</span>
                    <span>{item}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
