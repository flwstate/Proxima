import { motion } from 'motion/react';
import { DollarSign, TrendingUp, Users, Code, Megaphone, Award, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const allocationData = [
  { name: 'Product & Engineering', value: 28, amount: '£140-210K', color: '#FF7A00', icon: Code },
  { name: 'Marketing & Growth', value: 26, amount: '£130-195K', color: '#FF8C1A', icon: Megaphone },
  { name: 'Operations', value: 18, amount: '£90-135K', color: '#FF9E33', icon: Users },
  { name: 'Leadership & Team', value: 11, amount: '£55-82K', color: '#FFB04D', icon: Award },
  { name: 'Legal & Compliance', value: 9, amount: '£45-67K', color: '#FFC266', icon: Award },
  { name: 'Infrastructure', value: 8, amount: '£40-60K', color: '#FFD480', icon: TrendingUp },
];

const milestones = [
  { timeline: 'Month 3', goal: '10K verified users in London', metric: 'User growth' },
  { timeline: 'Month 6', goal: '50K users, 50 B2B venues', metric: 'Traction' },
  { timeline: 'Month 9', goal: 'UK expansion, 100K users', metric: 'Scale' },
  { timeline: 'Month 12', goal: 'Profitability path, Series A ready', metric: 'Exit/Growth' },
];

export function TheAskSection() {
  return (
    <section id="ask" className="relative py-24 bg-gradient-to-b from-[#0D0D0D] to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#FF8C1A] mb-6"
          >
            <DollarSign className="w-10 h-10 text-white" />
          </motion.div>
          
          <h2 className="mb-4 text-white">The Ask</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          
          <div className="max-w-3xl mx-auto">
            <div className="mb-4 text-[#FF7A00]" style={{ fontSize: '3rem', fontWeight: 'bold' }}>
              £500K – £750K
            </div>
            <p className="text-gray-400 text-lg mb-2">
              Seed funding for 12-16 month runway
            </p>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/20 border border-green-500/30 rounded-full text-green-400 text-sm">
              <Award className="w-4 h-4" />
              <span>SEIS/EIS Eligible – 50% Tax Relief for UK Investors</span>
            </div>
          </div>
        </motion.div>

        {/* Funding Allocation */}
        <div className="max-w-6xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-black to-[#0D0D0D] border-2 border-[#FF7A00]/30 rounded-lg overflow-hidden"
          >
            <div className="bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A] p-6">
              <h3 className="text-white text-center">Funding Allocation Breakdown</h3>
            </div>

            <div className="p-8">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                {/* Pie Chart */}
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={allocationData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={140}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${value}%`}
                      >
                        {allocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0D0D0D',
                          border: '1px solid #FF7A00',
                          borderRadius: '8px',
                          color: '#fff',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Breakdown List */}
                <div className="space-y-4">
                  {allocationData.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4 hover:border-[#FF7A00] transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-10 h-10 rounded-full flex items-center justify-center"
                            style={{ backgroundColor: `${item.color}20` }}
                          >
                            <item.icon className="w-5 h-5" style={{ color: item.color }} />
                          </div>
                          <div>
                            <h4 className="text-white text-sm">{item.name}</h4>
                            <p className="text-gray-500 text-xs">{item.amount}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xl" style={{ color: item.color }}>{item.value}%</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Milestones */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h3 className="text-center mb-8 text-white">12-Month Milestones</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-gradient-to-br from-black to-[#0D0D0D] border border-[#FF7A00]/30 rounded-lg p-6 text-center hover:border-[#FF7A00] transition-all"
              >
                <div className="text-[#FF7A00] mb-3">{milestone.timeline}</div>
                <h4 className="text-white mb-2 text-sm">{milestone.goal}</h4>
                <p className="text-gray-500 text-xs">{milestone.metric}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Investment Terms */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-r from-[#FF7A00]/20 to-transparent border-2 border-[#FF7A00] rounded-lg p-8 mb-12"
        >
          <h3 className="text-white mb-6">Investment Terms</h3>
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="text-[#FF7A00] mb-3">Structure</h4>
              <ul className="space-y-2 text-gray-300">
                <li>• SAFE note or equity</li>
                <li>• Pre-money valuation: £4-5M</li>
                <li>• 10-15% dilution</li>
                <li>• 20% discount on Series A</li>
              </ul>
            </div>
            <div>
              <h4 className="text-[#FF7A00] mb-3">Tax Benefits</h4>
              <ul className="space-y-2 text-gray-300">
                <li>• 50% SEIS income tax relief</li>
                <li>• CGT exemption on gains</li>
                <li>• Loss relief if needed</li>
                <li>• IHT relief after 2 years</li>
              </ul>
            </div>
            <div>
              <h4 className="text-[#FF7A00] mb-3">Investor Rights</h4>
              <ul className="space-y-2 text-gray-300">
                <li>• Monthly investor updates</li>
                <li>• Pro-rata rights in Series A</li>
                <li>• Advisory board seat (£100K+)</li>
                <li>• Information rights</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h3 className="text-white mb-8">Ready to Join the Journey?</h3>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              size="lg"
              className="bg-[#FF7A00] hover:bg-[#FF8C1A] text-white border-none shadow-[0_0_30px_rgba(255,122,0,0.5)] hover:shadow-[0_0_40px_rgba(255,122,0,0.7)] transition-all"
            >
              <Mail className="w-5 h-5 mr-2" />
              Contact Founder
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00] hover:text-white transition-all"
            >
              Download Investor Deck
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-black transition-all"
            >
              Schedule Meeting
            </Button>
          </div>

          <p className="text-gray-500 text-sm mt-8">
            Investment opportunities are limited. Reach out today to secure your position in the future of meaningful connection.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
