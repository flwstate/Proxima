import { motion } from 'motion/react';
import { Calendar, Users, Sparkles, TrendingUp, MapPin } from 'lucide-react';

const pillars = [
  {
    title: 'Multi-API Aggregation',
    icon: MapPin,
    description: 'Pulls events from Eventbrite, Ticketmaster, Facebook Events, Meetup, and local venues into one unified feed.',
    features: ['30+ event sources', 'Real-time updates', 'Deduplication AI'],
  },
  {
    title: 'AI Personality Matching',
    icon: Sparkles,
    description: 'Recommends events based on your MBTI profile, interests, past attendance, and social connections.',
    features: ['Personalized ranking', 'Interest clustering', 'Social graph analysis'],
  },
  {
    title: 'Event-Based Social Matching',
    icon: Users,
    description: 'See who else is attending and discover compatible connections before you even arrive at the event.',
    features: ['Pre-event networking', 'Compatibility scores', 'Mutual interests'],
  },
  {
    title: 'Machine Learning Intelligence',
    icon: TrendingUp,
    description: 'Predicts event attendance likelihood and suggests optimal events to maximize meaningful connections.',
    features: ['Attendance prediction', 'Behavior patterns', 'Success metrics'],
  },
];

const platformComparison = [
  { platform: 'Eventbrite', strength: 'Event ticketing', weakness: 'No personality matching' },
  { platform: 'Ticketmaster', strength: 'Major venues', weakness: 'No social features' },
  { platform: 'Facebook Events', strength: 'Social discovery', weakness: 'Privacy concerns, outdated' },
  { platform: 'Meetup', strength: 'Community groups', weakness: 'Limited personalization' },
  { platform: 'Proxima', strength: 'AI + Personality + Proximity + All Events', weakness: 'None – complete solution' },
];

export function EventsSection() {
  return (
    <section className="relative py-24 bg-gradient-to-b from-[#0D0D0D] to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Events Feature – Intelligent Event Discovery</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Never miss the perfect event. Our AI-powered system finds events tailored to your personality and connects you with compatible attendees.
          </p>
        </motion.div>

        {/* Four Pillars */}
        <div className="grid md:grid-cols-2 gap-6 mb-20">
          {pillars.map((pillar, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gradient-to-br from-black to-[#0D0D0D] border-2 border-[#FF7A00]/30 rounded-lg p-8 hover:border-[#FF7A00] transition-all group"
            >
              <motion.div
                className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#FF7A00]/10 mb-6 group-hover:bg-[#FF7A00]/20 transition-all"
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <pillar.icon className="w-8 h-8 text-[#FF7A00]" />
              </motion.div>

              <h3 className="mb-4 text-white group-hover:text-[#FF7A00] transition-colors">
                {pillar.title}
              </h3>

              <p className="text-gray-400 mb-6">{pillar.description}</p>

              <div className="space-y-2">
                {pillar.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#FF7A00]" />
                    <span className="text-gray-500">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Platform Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-8 text-white">How Proxima Compares</h3>
          <div className="overflow-x-auto">
            <div className="min-w-max">
              <div className="grid grid-cols-5 gap-4">
                {platformComparison.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className={`p-6 rounded-lg border-2 ${
                      item.platform === 'Proxima'
                        ? 'bg-gradient-to-br from-[#FF7A00]/20 to-transparent border-[#FF7A00] shadow-[0_0_30px_rgba(255,122,0,0.3)]'
                        : 'bg-black/50 border-gray-700'
                    }`}
                  >
                    <h4 className={`mb-4 text-center ${item.platform === 'Proxima' ? 'text-[#FF7A00]' : 'text-gray-400'}`}>
                      {item.platform}
                    </h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className={`mb-1 ${item.platform === 'Proxima' ? 'text-white' : 'text-gray-500'}`}>
                          Strength:
                        </p>
                        <p className={item.platform === 'Proxima' ? 'text-green-400' : 'text-gray-600'}>
                          {item.strength}
                        </p>
                      </div>
                      <div>
                        <p className={`mb-1 ${item.platform === 'Proxima' ? 'text-white' : 'text-gray-500'}`}>
                          Limitation:
                        </p>
                        <p className={item.platform === 'Proxima' ? 'text-green-400' : 'text-red-400'}>
                          {item.weakness}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Sample Event Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 max-w-2xl mx-auto"
        >
          <h3 className="text-center mb-6 text-white">Event Discovery Example</h3>
          <div className="bg-gradient-to-br from-black to-[#0D0D0D] border-2 border-[#FF7A00] rounded-lg overflow-hidden">
            {/* Event Header */}
            <div className="bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A] p-6">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-white mb-2">London Tech Startup Mixer</h4>
                  <div className="flex items-center gap-4 text-white/90 text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>Tomorrow, 7:00 PM</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>250m away</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white text-sm mb-1">Match Score</div>
                  <div className="text-2xl text-white">94%</div>
                </div>
              </div>
            </div>

            {/* Event Body */}
            <div className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-[#FF7A00]" />
                <span className="text-sm text-gray-400">12 compatible attendees including 3 mutual connections</span>
              </div>

              <div className="flex items-center gap-4 mb-4">
                <div className="flex -space-x-2">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF7A00] to-[#FF8C1A] border-2 border-black" />
                  ))}
                </div>
                <span className="text-sm text-gray-400">+47 others attending</span>
              </div>

              <div className="flex gap-3">
                <button className="flex-1 px-6 py-3 bg-[#FF7A00] hover:bg-[#FF8C1A] text-white rounded-lg transition-colors">
                  RSVP Now
                </button>
                <button className="px-6 py-3 border border-[#FF7A00] text-[#FF7A00] hover:bg-[#FF7A00] hover:text-white rounded-lg transition-all">
                  View Details
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
