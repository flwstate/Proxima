import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Users, Radio, Lock, Layers, Camera, MapPinned, FileText, Grid3x3 } from 'lucide-react';
import { Card } from './ui/card';

const features = [
  {
    title: 'Proximity Mapping',
    icon: MapPin,
    description: 'Real-time GPS, UWB, BLE, and Wi-Fi fusion for precise location awareness. Know who\'s around you with unprecedented accuracy.',
  },
  {
    title: 'Personality Matching',
    icon: Users,
    description: 'MBTI-powered FLWSTATE process analyzes compatibility across social, professional, and romantic contexts for meaningful connections.',
  },
  {
    title: 'Wave Feature',
    icon: Radio,
    description: 'Send anonymous proximity signals to express interest. Mutual waves unlock conversations, respecting privacy and consent.',
  },
  {
    title: 'Privacy Controls',
    icon: Lock,
    description: 'Stealth mode, safe zones, ghost mode, and granular visibility settings. You control who sees you, when, and where.',
  },
  {
    title: 'Multi-Use Mode',
    icon: Layers,
    description: 'Seamlessly switch between Social, Professional, and Dating contexts. One app, infinite possibilities.',
  },
  {
    title: 'AR Overlays',
    icon: Camera,
    description: 'Point your camera to discover people, events, and places around you with augmented reality visualization.',
  },
  {
    title: 'Local Service Discovery',
    icon: MapPinned,
    description: 'Find nearby services, venues, and businesses with AI-powered recommendations tailored to your preferences.',
  },
  {
    title: 'CV Upload',
    icon: FileText,
    description: 'Professional AI parses your CV to suggest relevant networking opportunities and career connections.',
  },
  {
    title: 'All-in-One Solution',
    icon: Grid3x3,
    description: 'Replace dating apps, LinkedIn, Meetup, and Yelp with a single intelligent platform designed for genuine connection.',
  },
];

export function SolutionSection() {
  const [selectedFeature, setSelectedFeature] = useState<number | null>(null);

  return (
    <section id="solution" className="relative py-24 bg-gradient-to-b from-[#0D0D0D] to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Solution & Core Features</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Proxima unifies real-time proximity intelligence with deep personality insights to create meaningful connections across every aspect of your life.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <Card
                className="bg-black/50 border-[#FF7A00]/30 p-6 h-full cursor-pointer hover:border-[#FF7A00] transition-all group relative overflow-hidden"
                onMouseEnter={() => setSelectedFeature(index)}
                onMouseLeave={() => setSelectedFeature(null)}
              >
                {/* Hover Glow Effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[#FF7A00]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={false}
                />

                <div className="relative z-10">
                  <motion.div
                    className="inline-flex items-center justify-center w-14 h-14 rounded-lg bg-[#FF7A00]/10 mb-4 group-hover:bg-[#FF7A00]/20 transition-all"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    <feature.icon className="w-7 h-7 text-[#FF7A00]" />
                  </motion.div>

                  <h3 className="mb-3 text-white group-hover:text-[#FF7A00] transition-colors">
                    {feature.title}
                  </h3>

                  <AnimatePresence>
                    {selectedFeature === index && (
                      <motion.p
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="text-gray-400 text-sm"
                      >
                        {feature.description}
                      </motion.p>
                    )}
                  </AnimatePresence>

                  {selectedFeature !== index && (
                    <p className="text-gray-500 text-sm">
                      Hover to learn more
                    </p>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Feature Highlight */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-8 rounded-r-lg"
        >
          <h3 className="mb-4 text-white">Why Proxima Stands Out</h3>
          <p className="text-gray-300 mb-4">
            Unlike fragmented solutions, Proxima combines cutting-edge proximity technology with personality-driven AI to deliver a unified experience. Whether you're looking for friends, dates, business connections, or local experiences, Proxima adapts to your needs in real-time.
          </p>
          <div className="flex flex-wrap gap-2">
            {['6-Layer AI System', 'Privacy-First Design', 'Multi-Context Matching', 'Real-Time Proximity'].map((tag, i) => (
              <span
                key={i}
                className="px-3 py-1 bg-[#FF7A00]/20 text-[#FF7A00] rounded-full text-sm border border-[#FF7A00]/30"
              >
                {tag}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
