import { motion } from 'motion/react';
import { CheckCircle2, Target, Code, Brain, FileCheck, Award, Rocket, Zap, Shield, MapPin } from 'lucide-react';

const milestones = [
  { title: 'MVP Developed', status: 'complete', icon: Code, description: 'Fully functional core app with proximity detection' },
  { title: 'AI Matching Implemented', status: 'complete', icon: Brain, description: 'MBTI-based compatibility system operational' },
  { title: 'Reflections Feature Live', status: 'complete', icon: MapPin, description: 'Geo-pinned content creation and discovery' },
  { title: 'Patent Application Drafted', status: 'complete', icon: FileCheck, description: 'Sensor fusion technology documentation' },
  { title: 'SEIS Eligible', status: 'complete', icon: Award, description: 'Seed Enterprise Investment Scheme approved' },
  { title: 'Beta Testing', status: 'in-progress', icon: Rocket, description: '150+ testers providing feedback' },
];

const upcomingPriorities = [
  {
    title: 'Verification Gateway',
    budget: '£120K',
    description: 'AI face scan, ID verification, and liveness detection',
    timeline: 'Q1 2025',
    icon: Shield,
  },
  {
    title: 'Proxima Zones Platform',
    budget: '£95K',
    description: 'Business dashboard and engagement tools',
    timeline: 'Q1-Q2 2025',
    icon: Target,
  },
  {
    title: 'UWB & BLE Integration',
    budget: '£80K',
    description: 'Ultra-wideband and Bluetooth proximity sensors',
    timeline: 'Q2 2025',
    icon: Zap,
  },
  {
    title: 'Algorithm Optimization',
    budget: '£60K',
    description: 'Machine learning model refinement and training',
    timeline: 'Q2 2025',
    icon: Brain,
  },
];

export function ProgressSection() {
  return (
    <section className="relative py-24 bg-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Progress & Roadmap</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Significant progress achieved. Clear roadmap to market leadership.
          </p>
        </motion.div>

        {/* Milestones Achieved */}
        <div className="mb-20">
          <h3 className="text-center mb-12 text-white">Milestones Achieved</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`bg-gradient-to-br from-black to-[#0D0D0D] border-2 rounded-lg p-6 ${
                  milestone.status === 'complete'
                    ? 'border-green-500/50'
                    : 'border-[#FF7A00]/50'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <motion.div
                    className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center ${
                      milestone.status === 'complete'
                        ? 'bg-green-500/20'
                        : 'bg-[#FF7A00]/20'
                    }`}
                    whileHover={{ scale: 1.1, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <milestone.icon
                      className={`w-6 h-6 ${
                        milestone.status === 'complete' ? 'text-green-500' : 'text-[#FF7A00]'
                      }`}
                    />
                  </motion.div>
                  {milestone.status === 'complete' && (
                    <CheckCircle2 className="w-6 h-6 text-green-500" />
                  )}
                  {milestone.status === 'in-progress' && (
                    <div className="flex items-center gap-1">
                      {[...Array(3)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="w-1.5 h-1.5 bg-[#FF7A00] rounded-full"
                          animate={{ scale: [1, 1.3, 1] }}
                          transition={{
                            duration: 1,
                            repeat: Infinity,
                            delay: i * 0.2,
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
                <h4 className="text-white mb-2">{milestone.title}</h4>
                <p className="text-gray-400 text-sm">{milestone.description}</p>
                <div className="mt-3 pt-3 border-t border-gray-800">
                  <span
                    className={`text-xs px-3 py-1 rounded-full ${
                      milestone.status === 'complete'
                        ? 'bg-green-500/20 text-green-500 border border-green-500/30'
                        : 'bg-[#FF7A00]/20 text-[#FF7A00] border border-[#FF7A00]/30'
                    }`}
                  >
                    {milestone.status === 'complete' ? 'Completed' : 'In Progress'}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Upcoming Funding Priorities */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-center mb-12 text-white">Upcoming Funding Priorities</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {upcomingPriorities.map((priority, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-gradient-to-br from-[#0D0D0D] to-black border border-[#FF7A00]/30 rounded-lg p-8 hover:border-[#FF7A00] transition-all group"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <motion.div
                      className="flex-shrink-0 w-14 h-14 rounded-full bg-[#FF7A00]/10 flex items-center justify-center group-hover:bg-[#FF7A00]/20 transition-all"
                      whileHover={{ scale: 1.1, rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <priority.icon className="w-7 h-7 text-[#FF7A00]" />
                    </motion.div>
                    <div>
                      <h4 className="text-white mb-1">{priority.title}</h4>
                      <p className="text-sm text-gray-500">{priority.timeline}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[#FF7A00]">{priority.budget}</div>
                  </div>
                </div>
                <p className="text-gray-400 text-sm">{priority.description}</p>

                {/* Progress Bar */}
                <div className="mt-6">
                  <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A]"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${20 + index * 15}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Planning</span>
                    <span>Development</span>
                    <span>Launch</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Timeline Visualization */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-12 bg-gradient-to-r from-[#FF7A00]/10 to-transparent border-l-4 border-[#FF7A00] p-8 rounded-r-lg"
          >
            <h4 className="text-white mb-6">12-Month Development Timeline</h4>
            <div className="space-y-4">
              {[
                { quarter: 'Q1 2025', focus: 'Verification Gateway + Zones Beta', progress: 60 },
                { quarter: 'Q2 2025', focus: 'Sensor Integration + Algorithm Optimization', progress: 40 },
                { quarter: 'Q3 2025', focus: 'Public Launch + Marketing Blitz', progress: 20 },
                { quarter: 'Q4 2025', focus: 'Scale & Partnerships', progress: 10 },
              ].map((q, i) => (
                <div key={i} className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white">{q.quarter}</span>
                    <span className="text-gray-400 text-sm">{q.focus}</span>
                  </div>
                  <div className="h-1.5 bg-black/50 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#FF7A00] to-[#FF8C1A]"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${q.progress}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
