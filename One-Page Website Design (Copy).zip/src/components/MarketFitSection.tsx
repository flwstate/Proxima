import { motion } from 'motion/react';
import { Users, Briefcase, MapPin, Store, TrendingUp } from 'lucide-react';

const opportunities = [
  {
    title: 'Addressing Social Isolation',
    icon: Users,
    stats: [
      { label: 'UK Loneliness Market', value: '£300M' },
      { label: 'Adults Affected', value: '45%' },
      { label: 'Young Adults Chronically Lonely', value: '31%' },
    ],
    description: 'Mental health crisis creating massive demand for authentic connection solutions. Proxima directly tackles loneliness through proximity-based, personality-matched social discovery.',
  },
  {
    title: 'Professional Networking Reinvented',
    icon: Briefcase,
    stats: [
      { label: 'LinkedIn Users (UK)', value: '33M+' },
      { label: 'Dissatisfaction Rate', value: '67%' },
      { label: 'Seeking Alternatives', value: '42%' },
    ],
    description: 'Traditional professional networking is broken. Proxima combines CV intelligence with real-time proximity to facilitate organic professional connections at conferences, coworking spaces, and events.',
  },
  {
    title: 'Hyper-Local Service Discovery',
    icon: MapPin,
    stats: [
      { label: 'Local Search Market', value: '£2.8B' },
      { label: 'Mobile-First Users', value: '88%' },
      { label: 'Location-Based Searches', value: '76%' },
    ],
    description: 'Users want personalized, real-time recommendations for nearby services. Proxima\'s AI combines personality matching with proximity for superior local discovery.',
  },
  {
    title: 'B2B & Venue Engagement',
    icon: Store,
    stats: [
      { label: 'UK Retail Market', value: '£394B' },
      { label: 'Foot Traffic Value', value: '£1.2B' },
      { label: 'Digital Engagement ROI', value: '340%' },
    ],
    description: 'Businesses need intelligent ways to engage nearby customers. Proxima Zones provides privacy-first, consent-based engagement with measurable ROI.',
  },
];

export function MarketFitSection() {
  return (
    <section id="market" className="relative py-24 bg-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="mb-4 text-white">Product-Market Fit & Opportunities</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#FF7A00] to-transparent mx-auto mb-6" />
          <p className="text-gray-400 max-w-3xl mx-auto text-lg">
            Massive, underserved markets converging at the intersection of proximity, AI, and meaningful connection
          </p>
        </motion.div>

        <div className="space-y-12">
          {opportunities.map((opp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gradient-to-br from-[#0D0D0D] to-black border border-[#FF7A00]/30 rounded-lg overflow-hidden hover:border-[#FF7A00] transition-all"
            >
              <div className="grid lg:grid-cols-3 gap-8 p-8">
                {/* Title & Icon */}
                <div className="lg:col-span-1">
                  <div className="flex items-center gap-4 mb-4">
                    <motion.div
                      className="flex-shrink-0 w-16 h-16 rounded-full bg-[#FF7A00]/10 flex items-center justify-center border-2 border-[#FF7A00]"
                      whileHover={{ scale: 1.1, rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <opp.icon className="w-8 h-8 text-[#FF7A00]" />
                    </motion.div>
                    <h3 className="text-white">{opp.title}</h3>
                  </div>
                  <p className="text-gray-400 text-sm">{opp.description}</p>
                </div>

                {/* Stats */}
                <div className="lg:col-span-2">
                  <div className="grid sm:grid-cols-3 gap-6">
                    {opp.stats.map((stat, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.9 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: index * 0.1 + i * 0.05 }}
                        className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6 text-center hover:border-[#FF7A00] transition-all"
                      >
                        <div className="mb-2 text-[#FF7A00]" style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                          {stat.value}
                        </div>
                        <p className="text-gray-400 text-sm">{stat.label}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Overall Market Summary */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 bg-gradient-to-r from-[#FF7A00]/20 to-transparent border-2 border-[#FF7A00] rounded-lg p-8"
        >
          <div className="flex items-center gap-4 mb-6">
            <TrendingUp className="w-12 h-12 text-[#FF7A00]" />
            <div>
              <h3 className="text-white mb-1">Total Addressable Market</h3>
              <p className="text-gray-400">Converging multi-billion dollar opportunities</p>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { label: 'Social Connection Apps', value: '£1.2B', growth: '+23% YoY' },
              { label: 'Professional Networking', value: '£890M', growth: '+18% YoY' },
              { label: 'Local Discovery', value: '£2.8B', growth: '+31% YoY' },
              { label: 'Location-Based Services', value: '£4.1B', growth: '+42% YoY' },
            ].map((market, i) => (
              <div key={i} className="bg-black/50 border border-[#FF7A00]/30 rounded-lg p-6">
                <p className="text-sm text-gray-400 mb-2">{market.label}</p>
                <div className="text-2xl text-[#FF7A00] mb-1">{market.value}</div>
                <p className="text-xs text-green-400">{market.growth}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
